const form = document.getElementById('jobApplicationForm');
const viewTableBtn = document.getElementById('viewTableBtn');
const dataTable = document.getElementById('dataTable');

form.addEventListener('submit', function(event) {
    event.preventDefault();
    if (validateForm()) {
        const formData = new FormData(form);
        const data = {};
        for (let [key, value] of formData.entries()) {
            data[key] = value;
        }
        console.log(data);
    }
});

viewTableBtn.addEventListener('click', function() {
    const formData = new FormData(form);
    const data = {};
    for (let [key, value] of formData.entries()) {
        data[key] = value;
    }
    displayDataAsTable(data);
});

function validateForm() {
    // Add your validation logic here
    return true; // Change to return false if validation fails
}

function displayDataAsTable(data) {
    const tableHeader = '<tr><th>Field</th><th>Value</th></tr>';
    let tableRows = '';
    for (let key in data) {
        let value = data[key];
        // Check if the value is a File object
        if (value instanceof File) {
            value = value.name; // Use the file name for display
        }
        // Handle boolean values for relocation
        if (key === 'relocate') {
            value = value === 'yes' ? 'Yes' : 'No';
        }
        tableRows += `<tr><td>${key}</td><td>${value}</td></tr>`;
    }
    dataTable.innerHTML = tableHeader + tableRows;
}
